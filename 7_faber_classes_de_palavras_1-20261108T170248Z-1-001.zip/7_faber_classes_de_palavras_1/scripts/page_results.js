//=========================================
// File name: page_results.js
//-----------------------------------------
// Project : QuizFaber 4.0.20
// Licence : GNU General Public License v3.0
// Author  : Luca Galli
// Email   : info@quizfaber.com
//-----------------------------------------
// Functions included in this file:
// - ready()
// - on beforeunload
// - GetTypeOfSubstitution() - code generated
// - GetRemFromMark() - code generated
// - GetLinkFromMark() - code generated
//=========================================

$(document).ready(function () {
	PageLoadResult();
});

$(window).on("beforeunload", function ()
{
	if (!closedFromBrowser) {
		PageUnloadIndex();
	}
	else {
		ClearQuiz();
	}
});

/* Code generated function */
function GetTypeOfSubstitution(aMark)
{
    if ((aMark>=0)&&(aMark<15)) return QMAKE_VALUATION_NEAR_TO_MARK;
    else if ((aMark>=16)&&(aMark<18)) return QMAKE_VALUATION_NEAR_TO_MARK;
    else if ((aMark>=19)&&(aMark<=20)) return QMAKE_VALUATION_NEAR_TO_MARK;
    else return 0;

}


/* Code generated function */
function GetRemFromMark(aMark)
{
    if ((aMark>=0)&&(aMark<15)) return "Por favor, clica em 'Repetir'! Vais conseguir um resultado melhor.";
    if ((aMark>=16)&&(aMark<18)) return "Foi por pouco! Podes melhorar o resultado! Clica em 'Repetir'.";
    if ((aMark>=19)&&(aMark<=20)) return "Muito bem!";
    return "";

}


/* Code generated function */
function GetLinkFromMark(aMark)
{
    return "";

}



