//=========================================
// File name: page_NNNNN.js
//-----------------------------------------
// Project : QuizFaber 4.0.20
// Licence : GNU General Public License v3.0
// Author  : Luca Galli
// Email   : info@quizfaber.com
//-----------------------------------------
// Script for NNNNN-th question
//=========================================

var allInitQuestionFunctions = new Array (
    InitQuestion1,
);



$(document).ready(function ()
{
	const questionIndex = 0;
	const questionTime = 0;

	PageLoad(questionIndex, questionTime);

	
});

$(window).on("beforeunload", function ()
{
	PageUnload();
});

$(window).on("scroll", function ()
{
	PageOnScroll();
});


/* Code generated function */
function InitQuestion1()
{
    const type = QMAKE_BOOLEAN;
    const questionIndex = 0;
    var choice, valuation, noChoice = false;;
    var weight = DecodeNumber('8kySkcMzbnA=', 869, 0, 99999);
    var numOfAnswers = 20;
    var question = new Question(type, weight, numOfAnswers);
    question.answers.length = 0;
    question.shortTextQuestion = "Assinala as afirma��es verdadeiras e as falsas:";
    choice = GetBooleanChoice(questionIndex,0);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 0);
    valuation = DecodeNumber('bYT/QMyvv3k=', 869, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer0 = new Answer(choice, valuation, 1, 0, '');
    answer0.shortTextAnswer = "S� h� nomes nesta s�rie: selva � bicho � �rvore � gorila � perigoso";
    question.answers.push(answer0);
    choice = GetBooleanChoice(questionIndex,1);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 1);
    valuation = DecodeNumber('l9x9lPutULc=', 230, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer1 = new Answer(choice, valuation, 1, 0, '');
    answer1.shortTextAnswer = "A frase \"Viste os meus amigos?\" cont�m dois determinantes.";
    question.answers.push(answer1);
    choice = GetBooleanChoice(questionIndex,2);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 2);
    valuation = DecodeNumber('PBpoYKGlCc4=', 232, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer2 = new Answer(choice, valuation, 1, 0, '');
    answer2.shortTextAnswer = "D�-me o livro cuja capa � verde. �� \"cuja\" � um determinante relativo.";
    question.answers.push(answer2);
    choice = GetBooleanChoice(questionIndex,3);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 3);
    valuation = DecodeNumber('1NAB+HRVU74=', 234, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer3 = new Answer(choice, valuation, 1, 0, '');
    answer3.shortTextAnswer = "Ele tem o dobro do trabalho. ��  \"dobro\" � um quantificador numeral.";
    question.answers.push(answer3);
    choice = GetBooleanChoice(questionIndex,4);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 4);
    valuation = DecodeNumber('Nan4EbtOkTc=', 236, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer4 = new Answer(choice, valuation, 1, 0, '');
    answer4.shortTextAnswer = "H� dois adjetivos na frase \"O colega ucraniano � divertido.\"";
    question.answers.push(answer4);
    choice = GetBooleanChoice(questionIndex,5);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 5);
    valuation = DecodeNumber('SkXXryzqR0o=', 74, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer5 = new Answer(choice, valuation, 1, 0, '');
    answer5.shortTextAnswer = "O superlativo absoluto sint�tico de am�vel � \"amavil�ssimo\".";
    question.answers.push(answer5);
    choice = GetBooleanChoice(questionIndex,6);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 6);
    valuation = DecodeNumber('ggnRGo01WZQ=', 76, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer6 = new Answer(choice, valuation, 1, 0, '');
    answer6.shortTextAnswer = "O superlativo absoluto Sint�tico de bom � \"muito bom\".";
    question.answers.push(answer6);
    choice = GetBooleanChoice(questionIndex,7);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 7);
    valuation = DecodeNumber('vu8xazhJmBs=', 78, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer7 = new Answer(choice, valuation, 1, 0, '');
    answer7.shortTextAnswer = "Usando pronomes, a frase \"Dei um l�pis � Ana.\" transforma-se em \"Dei-lho.\"";
    question.answers.push(answer7);
    choice = GetBooleanChoice(questionIndex,8);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 8);
    valuation = DecodeNumber('InqaJx6CphA=', 80, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer8 = new Answer(choice, valuation, 1, 0, '');
    answer8.shortTextAnswer = "H� quatro pronomes na frase \"Ele prometeu tudo, mas n�o nos deu nada. \"";
    question.answers.push(answer8);
    choice = GetBooleanChoice(questionIndex,9);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 9);
    valuation = DecodeNumber('Rv6V7wGB51o=', 441, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer9 = new Answer(choice, valuation, 1, 0, '');
    answer9.shortTextAnswer = "Que e Quem s�o pronomes relativos invari�veis.";
    question.answers.push(answer9);
    choice = GetBooleanChoice(questionIndex,10);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 10);
    valuation = DecodeNumber('EeMj+gWvCQ4=', 443, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer10 = new Answer(choice, valuation, 1, 0, '');
    answer10.shortTextAnswer = "A forma verbal amasse est� no pret�rito imperfeito do conjuntivo.";
    question.answers.push(answer10);
    choice = GetBooleanChoice(questionIndex,11);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 11);
    valuation = DecodeNumber('EeMj+gWvCQ4=', 445, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer11 = new Answer(choice, valuation, 1, 0, '');
    answer11.shortTextAnswer = "Acordar, vir, ter - s�o todos verbos irregulares.";
    question.answers.push(answer11);
    choice = GetBooleanChoice(questionIndex,12);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 12);
    valuation = DecodeNumber('N+UYlGnn7Ek=', 447, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer12 = new Answer(choice, valuation, 1, 0, '');
    answer12.shortTextAnswer = "Um tempo composto � constitu�do por v. auxiliar + v. principal ou copulativo.";
    question.answers.push(answer12);
    choice = GetBooleanChoice(questionIndex,13);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 13);
    valuation = DecodeNumber('RIt5zs3Zx6U=', 285, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer13 = new Answer(choice, valuation, 1, 0, '');
    answer13.shortTextAnswer = "A frase \"Ele vive em Braga.\" cont�m um verbo copulativo. ";
    question.answers.push(answer13);
    choice = GetBooleanChoice(questionIndex,14);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 14);
    valuation = DecodeNumber('D1Nd+rYKNsg=', 287, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer14 = new Answer(choice, valuation, 1, 0, '');
    answer14.shortTextAnswer = "H� dois adv�rbios na frase \"Vem c� imediatamente.\"";
    question.answers.push(answer14);
    choice = GetBooleanChoice(questionIndex,15);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 15);
    valuation = DecodeNumber('1AIkgMVyhdQ=', 289, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer15 = new Answer(choice, valuation, 1, 0, '');
    answer15.shortTextAnswer = "1. O mal est� feito. 2. V�s mal? �� \"mal\" � um adv�rbio apenas na frase 2.";
    question.answers.push(answer15);
    choice = GetBooleanChoice(questionIndex,16);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 16);
    valuation = DecodeNumber('1AIkgMVyhdQ=', 291, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer16 = new Answer(choice, valuation, 1, 0, '');
    answer16.shortTextAnswer = "A frase \"Passeio com o meu c�o de manh�.\" cont�m tr�s preposi��es. ";
    question.answers.push(answer16);
    choice = GetBooleanChoice(questionIndex,17);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 17);
    valuation = DecodeNumber('1tlmnxeB5YA=', 652, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer17 = new Answer(choice, valuation, 1, 0, '');
    answer17.shortTextAnswer = "Como estavas s�, vim. �� \"Como\" � uma conjun��o subordinativa causal. ";
    question.answers.push(answer17);
    choice = GetBooleanChoice(questionIndex,18);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 18);
    valuation = DecodeNumber('1tlmnxeB5YA=', 654, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer18 = new Answer(choice, valuation, 1, 0, '');
    answer18.shortTextAnswer = "Vim logo que pude. �� \"logo que\" � uma locu��o subordinativa condicional. ";
    question.answers.push(answer18);
    choice = GetBooleanChoice(questionIndex,19);
    noChoice = noChoice || !IsBooleanChoiceSelected(questionIndex, 19);
    valuation = DecodeNumber('mOKp1SdBwFo=', 656, -1, 1);
    if (valuation === -2) PrintWrongKeyword(questionIndex);
    var answer19 = new Answer(choice, valuation, 1, 0, '');
    answer19.shortTextAnswer = "Uf! Finalmente em casa! �� \"Uf!\" � uma interjei��o que exprime al�vio. ";
    question.answers.push(answer19);
    question.noChoice = noChoice;
    return question;

}






